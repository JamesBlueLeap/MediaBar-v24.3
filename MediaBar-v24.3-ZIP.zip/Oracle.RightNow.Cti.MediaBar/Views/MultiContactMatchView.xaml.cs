﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Oracle.RightNow.Cti.MediaBar.Views
{
	/// <summary>
	/// Interaction logic for MultiContactMatchView.xaml
	/// </summary>
	public partial class MultiContactMatchView : Window
	{
		private EventHandler _onContactSelected;

		public MultiContactMatchView(List<ListViewRowModel> contacts, EventHandler onContactSelected)
		{
			InitializeComponent();
			lvContacts.ItemsSource = contacts;
			_onContactSelected = onContactSelected;
		}

		private void lvContacts_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			ListViewRowModel item = ((FrameworkElement)e.OriginalSource).DataContext as ListViewRowModel;

			if (item != null && _onContactSelected != null)
			{
				_onContactSelected(sender, new MultiContactMatchViewCallbackEventArgs(item.ID));
				this.Close();
			}
		}

        private void lvContacts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

    public class ListViewRowModel
	{
		public long ID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string StudentID { get; set; }
		public string Email { get; set; }
		public string Address { get; set; }
	}

	public class MultiContactMatchViewCallbackEventArgs : EventArgs
	{
		private long _contactID;

		public long ContactID
		{
			get
			{
				return _contactID;
			}
		}

		public MultiContactMatchViewCallbackEventArgs(long contactID)
		{
			_contactID = contactID;
		}
	}
}
