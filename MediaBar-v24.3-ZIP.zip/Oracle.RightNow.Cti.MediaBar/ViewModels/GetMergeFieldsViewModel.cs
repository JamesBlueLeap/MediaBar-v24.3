﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oracle.RightNow.Cti.MediaBar.ViewModels
{
    class GetMergeFieldsViewModel : ViewModel
    {
        public GetMergeFieldsViewModel(Action<bool> resultHandler, RightNowObjectProvider rnObject, string caption = "Create Campaign")
        {
        }
    }
}
