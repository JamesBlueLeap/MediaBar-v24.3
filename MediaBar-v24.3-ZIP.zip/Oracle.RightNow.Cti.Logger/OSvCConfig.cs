﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oracle.RightNow.Cti.Logger
{
    public static class OSvCConfig
    {
        public static String CTIPrimaryKey { get; set; }
    }
}
