﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oracle.RightNow.Cti.MediaBar
{
    public static class mediabarConfiguration
    {
        public static bool showSMSButtonNewProp { get; set; }
        public static bool enableSMSButtonProp { get; set; }
        public static string SMSButtonIconPath { get; set; }
        public static bool ConnectDisconnectBtn { get; set; }
        public static bool comboAgentState { get; set; }
        public static bool DialPadBtn { get; set; }
        public static bool AssociateContactBtn { get; set; }
        public static bool UnAssociateContactBtn { get; set; }
        public static bool WebRTCButton { get; set; }
        public static bool campaigns { get; set; }
        public static bool agentText { get; set; }
        public static bool agentExtn { get; set; }
        public static bool showTemplates { get; set; }
        public static bool showPersonalization { get; set; }
        public static String CTIPrimaryKey { get; set; }
    }
}
