﻿// ===========================================================================================
//  Oracle RightNow Connect
//  CTI Sample Code
// ===========================================================================================
//  Copyright © Oracle Corporation.  All rights reserved.
// 
//  Sample code for training only. This sample code is provided "as is" with no warranties 
//  of any kind express or implied. Use of this sample code is pursuant to the applicable
//  non-disclosure agreement and or end user agreement and or partner agreement between
//  you and Oracle Corporation. You acknowledge Oracle Corporation is the exclusive
//  owner of the object code, source code, results, findings, ideas and any works developed
//  in using this sample code.
// ===========================================================================================
  
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Oracle.RightNow.Cti;
using Oracle.RightNow.Cti.Model;

namespace Oracle.RightNow.Cti.MediaBar {
    //public class InteractionViewModel : NotifyingObject {
    //    private readonly IInteraction _interaction;
    //    private SynchronizationContext _synchrhonizationContext;

    //    public InteractionViewModel(IInteraction interaction, SynchronizationContext context = null) {
    //        _synchrhonizationContext = context;
    //        _interaction = interaction;
    //        _interaction.PropertyChanged += interaction_PropertyChanged;
    //    }

    //    public string Id { get { return _interaction.Id; } }

    //    public string Address {
    //        get {
    //            return _interaction.Address;
    //        }
    //    }

    //    public InteractionState State {
    //        get {
    //            return _interaction.State;
    //        }
    //    }

    //    private void interaction_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e) {
    //        if (_synchrhonizationContext != null) {
    //            _synchrhonizationContext.Post(new System.Threading.SendOrPostCallback(o => OnPropertyChanged(o.ToString())), e.PropertyName);
    //        }
    //        else
    //            OnPropertyChanged(e.PropertyName);
    //    }
    //}
}